<a class='btn btn-app' href='<?php echo $url; ?>' target='<?php echo $target; ?>'>
	<?php echo $badge; ?><i class='<?php echo $icon; ?>'></i> <?php echo $label; ?>
</a>