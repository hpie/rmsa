<!-- content -->
<div class="col-md-6 col-sm-8  col-12">
    <div class="middle-area">
        <h2 class="heading">Organization</h2>
        <img src="https://rmsahimachal.nic.in/images/organisationdistrict.jpg" alt="">

    </div>
</div>
