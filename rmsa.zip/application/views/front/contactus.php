<!-- content -->
<div class="col-md-6 col-sm-8  col-12">
    <div class="middle-area">
        <h1 class="heading">Contact Us</h1>
        <h5>Contact Numbers of RMSA Officers, Directorate of Higher Education, Shimla - 171001 (HP)
        </h5>
        <table class="table table-borderless table-responsive contact_us">
            <thead class="bg-gray">
            <tr>
                <th scope="col">KWord</th>
                <th scope="col">Designation</th>
                <th scope="col">Email</th>
                <th scope="col">Phone Office</th>
                <th scope="col">Pbx No.</th>
                <th scope="col">Mobile No.</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th scope="row">Sh. Ghanshyam Chand</th>
                <td>State Project Director</td>
                <td>gcshyam46@gmail.com </td>
                <td>0177-2807105</td>
                <td>300</td>
                <td>9418002410</td>
            </tr>

            </tbody>
        </table>
    </div>
</div>