<div class="col-md-6 col-sm-8  col-12">
    <div class="middle-area">
        <h1 class="heading">View Information Uploaded on the Portal</h1>
        <form class="form-horizontal border p-2" action="#">
            <h2 class="second-heading">View Information</h2>
            <div class="form-group">
                <div class="row">
                    <label class="control-label col-sm-4 col-xs-12" for="distt">Class:</label>
                    <div class="col-sm-8 col-xs-12">
                        <select class="form-control">
                            <option>Select Class</option>
                            <option>Class IX</option>
                            <option>Class X</option>
                            <option>Class XI</option>
                            <option>Class XII</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label class="control-label col-sm-4 col-xs-12" for="tehsil">Subject:</label>
                    <div class="col-sm-8 col-xs-12">
                        <select class="form-control">
                            <option value="0">---Select---</option>
                        </select>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-md-12 col-sm-12  col-12">
    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Title</th>   
                <th>Type</th>
                <th>Group</th>
                <th>Category</th>
                <th>Description</th>
                <th>File</th>
                <th>Child</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Title</th>   
                <th>Type</th>
                <th>Group</th>
                <th>Category</th>
                <th>Description</th>
                <th>File</th>
                <th>Child</th>
            </tr>
        </tfoot>
    </table>
</div>

