<!-- content -->
<div class="col-md-6 col-sm-8  col-12">
    <div class="middle-area">
        <h1 class="heading">Reports</h1>
        <h5>RMSA Reports</h5>
        <table class="table table-borderless table-responsive contact_us">
            <thead class="bg-gray">
            <tr>
                <th scope="col">Report Type</th>
                <th scope="col">Year</th>
                <th scope="col">Download Link</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th scope="row">Financial Report</th>
                <td>2018-2019</td>
                <td><a href="#">Download Report</a></td>
            </tr>

            </tbody>
        </table>
    </div>
</div>
