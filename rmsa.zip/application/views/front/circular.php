<!-- content -->
<div class="col-md-6 col-sm-8  col-12">
    <div class="middle-area">
        <h2 class="heading">Circulars</h2>

        <ul>
            <li><a href="#"> Registered Schools</a></li>
            <li><a href="#"> ITPD ENGLISH</a></li>
            <li><a href="#">ITPD HINDI</a></li>
            <li><a href="#"> ITPD SANSKRIT</a></li>
            <li><a href="#">ITPD SOCIAL SCIENCE</a></li>
            <li><a href="#">RMSA Resource Pool In Six States</a></li>
            <li><a href="#">Report Of SLAS 2015</a></li>
            <li><a href="#">State Resource Group Details</a></li>
            <li><a href="#">Guidelines For Logging In RMSA Portal</a></li>
            <li><a href="#">Swayamsidham Project PPT</a></li>
            <li><a href="#">Part-I Instruction To Be Followed By The State Level Achievement Survey On November 21, 2015</a></li>
            <li><a href="#"> Part-II Instruction To Be Followed By The State Level Achievement Survey On November 21, 2015</a></li>
        </ul>
    </div>
</div>