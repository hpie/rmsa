    <!-- Footer Start -->   
        <footer>
            <div class="wapper">
                <div>
                    <p> <strong style="color:red;">Disclaimer : </strong> The website has been designed and developed by
                        <a href="http://hpie.in"> H.P.I.E </a> and the content on this website is published and managed by the HP 
                        Education Department, who is responsible for updating website content. The content provided is informative
                        only. Neither Education Department nor H.P.I.E is responsible for any inadvertent errors. For any query 
                        related to this website, please contact the Web Information Manager, Ms. Anima Sharma, Ph. No.
                        0177-2807105, animasharma3004@gmail.com.</p>
                    <img src="<?php echo BASE_URL; ?>/assets/front/img/nic.png" alt="nic" title="nic">
                </div>
            </div>
        </footer>
    <!-- Footer End -->
