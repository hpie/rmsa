		<!-- RightNavbar Start -->			
  
                    <div class="col-md-3 col-sm-4 col-12 ">
                        <div class="right-side-area">
                            <h1><a href="#">Message from Hon'ble Minister</a></h1>
                            <div class="marque">
                                <marquee style="height:150px;" direction="up" behaviour="scroll" scrollamount="4"
                                    title="Holding your cursor over this stops the marquee" onmouseover="this.stop();"
                                    onmouseout="this.start();">
                                    <ul>
                                        <li><a href="#">This is a link 1</a></li>
                                        <li><a href="#">Lorem ipsum dolor sit amet.</a></li>
                                        <li><a href="#">Lorem ipsum dolor sit amet consectetur adipisicing elit.</a>
                                        </li>
                                        <li><a href="#">Lorem ipsum dolor sit.</a></li>
                                        <li><a href="#">lorem2 click</a></li>
                                        <li><a href="#">Lorem ipsum dolor sit amet consectetur adipisicing.</a></li>
                                        <li><a href="#">Lorem ipsum dolor sit amet consectetur adipisicing elit. Error,
                                                excepturi sint. Qui?</a></li>
                                        <li><a href="#">Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                                                Officia, deserunt.</a></li>
                                    </ul>
                                </marquee>
                            </div>
                        </div>
					</div>
      
			<!-- RightNavbar End -->			